import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:8080/api/v1/';
  private baseUrlFilter = 'http://localhost:8080/api/v1/';

  constructor(private http: HttpClient) { }

  getProductListByDate(date1: any,date2:any): Observable<any> {
    let params = new HttpParams();
    params = params.append('date1', date1);
    params = params.append('date2', date2);
    return this.http.get(`${this.baseUrl}`+"productsFilter", {params: params});
  }

  getProductList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+"products");
  }
}
