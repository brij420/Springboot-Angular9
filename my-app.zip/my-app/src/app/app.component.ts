import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs";
import { ProductService } from "./product.service";
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  start_date: string = '';
  end_date: string = '';
  pipe = new DatePipe('en-US');
  now = Date.now();

  columnDefs = [
    {headerName: 'City', field: 'city', sortable: true, filter: true},
    {headerName: 'Color', field: 'color', sortable: true, filter: true},
    {headerName: 'Price', field: 'price', sortable: true, filter: true},
    {headerName: 'Status', field: 'status', sortable: true, filter: true},
    {headerName: 'Start Date', field: 'start_date', sortable: true, filter: true},
    {headerName: 'End Date', field: 'end_date', sortable: true, filter: true}
];
rowData : any;

constructor(private productService: ProductService) {

}
ngOnInit() {
  this.reloadData();
}
reloadData() {
   this.productService.getProductList().subscribe(
    data => {
      this.rowData=data;
      console.log(data);
     
    },
    error => console.log(error));
}
filterFunction() {
  this.productService.getProductListByDate(this.pipe.transform(this.start_date, 'MM/dd/yyyy'),this.pipe.transform(this.end_date, 'MM/dd/yyyy')).subscribe(
    data => {
      this.rowData=data;
      console.log(data);
     
    },
    error => console.log(error));
   
    
 
  console.log(this.pipe.transform(this.start_date, 'MM/dd/yyyy'));
  console.log(this.pipe.transform(this.end_date, 'MM/dd/yyyy'));
  
}

clearFilterFunction(){
  this.start_date="";
  this.end_date="";
}
}
